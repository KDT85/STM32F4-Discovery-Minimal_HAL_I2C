/**
  ******************************************************************************
  * @file: serialio.h
  * @author: Luke Emery // Ki Talbot
  * @version: 1.0
  * @date: 03/02/2024
  * @brief: Initialise and implement functions for IO over UART
  *
  * using the RS232 serial port on the DM-STF-4BB
  * expansion board. Configure the hardware to have USB Mini
  * for power and RS232 to USB via a null modem for serial
  * communication to the host PC. This should appear as a
  * COM port which can be configured in a terminal of choice
  * such as PuTTY or the STM32CubeIDE terminal as follows:
  *
  * - Baud				: 115200
  * - Word length		: 8 bits
  * - Stop bit			: 1
  * - Parity			: None
  * - Flow Control		: None
  *
  * As functions in C are "extern" by default, the "extern"
  * keyword could be omitted but is included for the sake
  * of readability.
  *
  * In addition to the function declared
  * in this file, the source file is responsible for
  * providing the concrete implementations of low level
  * IO functions, which are provided as "weak" by the STM
  * libraries.
  *
  * When using these utilities to support stdio, remember to set:
  * @code setvbuf(stdin, NULL, _IONBF, 0);
  * to disable buffering.
  *
  * A source file using these utilities to support stdio must also include:
  * @code <stdio.h>
  * in addition to this header.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 Staffordshire University
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

#ifndef SRC_SERIALIO_SERIALIO_H_
#define SRC_SERIALIO_SERIALIO_H_


/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"


/* Global variables ----------------------------------------------------------*/


/* Function prototypes (code generation followed by alphabetical) ------------*/
extern void init_serial_io(void);


#endif /* SRC_SERIALIO_SERIALIO_H_ */
